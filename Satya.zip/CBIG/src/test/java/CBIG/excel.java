package CBIG;

import java.io.IOException;

import org.testng.annotations.Test;

import Utilities.ExtractExcelData;

public class excel {

	@Test
	public void  sollu() throws IOException
	{
		ExtractExcelData ed = new ExtractExcelData();
		
		String n=ed.GetObjectData("CLG_Details","CLGNumber");
		System.out.println(n);
	}
}
