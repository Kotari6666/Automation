package CBIG;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import CBIG_PageObjects.BorrowerDetails;
import CBIG_PageObjects.CLG_Details;
import CBIG_PageObjects.CPID_Page;
import CBIG_PageObjects.EntityDetails;
import CBIG_PageObjects.LandingPage;
import CBIG_PageObjects.SelectCustomerGroup;
import Utilities.Base;
import Utilities.ExtractExcelData;
import Utilities.JSLoad;
import Utilities.SwitchWindow;

public class BasicTest {

	@Test

	public void Basic() throws IOException, InterruptedException {

		// Intialising Base class to create Webdriver with prequistes and launching url
		Base base = new Base();

		WebDriver driver = base.intializeDriver();
		driver = base.URL(driver);

		// declaring test level requierd objects and classes
		WebDriverWait wait = new WebDriverWait(driver, 10);
		SwitchWindow switchWindow = new SwitchWindow();
		ExtractExcelData exc = new ExtractExcelData();
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("D:\\Satya\\CBIG\\Configuration.properties");
		prop.load(fis);
		String sheet1 = "CLG_Details";
		String sheet2 = "Entity_Details";
		String sheet3 = "Borrower_Details";
		

		// calling Landing page to launch cbig
		LandingPage lp = new LandingPage(driver);
		lp.ClickCbig().click();

		// calling SwitchToChildWindow to change focus to new window and maximizing it
		switchWindow.SwitchToChildWindow(driver);
		driver = base.Maximize(driver);

		// calling CPID_Page to click on ROOO CPID
		CPID_Page cp = new CPID_Page(driver);
		cp.Country().click();
		cp.District().click();
		cp.Region().click();
		cp.Region_2().click();
		cp.CPID_R0000().click();

		// calling SelectCustomerGroup to add CLG
		SelectCustomerGroup scg = new SelectCustomerGroup(driver);
		scg.AddCGButton().click();

		// calling CLG_Details to enter data in CLG details page
		CLG_Details clg = new CLG_Details(driver);
		Thread.sleep(2000);
		System.out.println(exc.GetObjectData(sheet1,"CLGNumber"));
		clg.CLGNumber().sendKeys(exc.GetObjectData(sheet1,"CLGNumber"));
		clg.customerGroupName().sendKeys(exc.GetObjectData(sheet1,"customerGroupName"));
		clg.ANZSICcode().sendKeys(exc.GetObjectData(sheet1,"ANZSICcode"));
		new Actions(driver).sendKeys(Keys.TAB).build().perform();

		// calling JSLoad to wait untill page loads with ANZSIIC Description
		JSLoad js = new JSLoad(driver);
		Boolean load = js.waitforJStoLoad();
		Assert.assertTrue(load);

		clg.customerSince().sendKeys(exc.GetObjectData(sheet1,"customerSince"));
		new Select(clg.contactTitle()).selectByVisibleText(exc.GetObjectData(sheet1,"contactTitle"));
		clg.contactName().sendKeys(exc.GetObjectData(sheet1,"contactName"));
		clg.address().sendKeys(exc.GetObjectData(sheet1,"address"));
		clg.city().sendKeys(exc.GetObjectData(sheet1,"city"));
		new Select(clg.state()).selectByVisibleText(exc.GetObjectData(sheet1,"state"));
		clg.country().sendKeys(exc.GetObjectData(sheet1,"country"));
		clg.postcode().sendKeys(exc.GetObjectData(sheet1,"postcode"));
		clg.phoneNumber().sendKeys(exc.GetObjectData(sheet1,"phoneNumber"));
		clg.mobile().sendKeys(exc.GetObjectData(sheet1,"mobile"));
		clg.facimileNumber().sendKeys(exc.GetObjectData(sheet1,"facimileNumber"));
		clg.emailAddress().sendKeys(exc.GetObjectData(sheet1,"emailAddress"));
		clg.save().click();
		driver.switchTo().alert().accept();
		String msg = driver.findElement(By.id("SucMsg")).getText();
		Assert.assertEquals(msg, prop.getProperty("CLGSuccessMessage"));

		// calling EntitDetails to enter data in Entity details page
		EntityDetails entd = new EntityDetails(driver);
		entd.entityDetails().click();
		entd.add().click();

		// calling SwitchToSubchildWindow to shift focus to new window
		switchWindow.SwitchToSubChildWindow(driver);
		Boolean load2 = js.waitforJStoLoad();
		Assert.assertTrue(load2);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(entd.entityType));
		new Select(entd.entityType()).selectByVisibleText(exc.GetObjectData(sheet2,"entityType"));
		entd.entityName().sendKeys(exc.GetObjectData(sheet2,"entityName"));
		entd.sequenceNo().sendKeys(exc.GetObjectData(sheet2,"sequenceNo"));
		entd.save().click();
		Thread.sleep(1000);

		// calling SwitchToChildWindow to shift focus back
		switchWindow.SwitchToChildWindow(driver);
		entd.changeCGbutton().click();
		
		//entering CLG number and opening CLG
		scg.CLGNumber().sendKeys(exc.GetObjectData(sheet1,"CLGNumber"));
		scg.SearchButton().click();;
		scg.resultCLG().getText();
		Assert.assertEquals(scg.resultCLG().getText(), exc.GetObjectData(sheet1,"CLGNumber"));
		scg.resultCLG().click();
		scg.open().click();
		
		//Adding borrower in Borrwer details
		BorrowerDetails bd = new BorrowerDetails(driver);
		bd.add().click();
		switchWindow.SwitchToSubChildWindow(driver);
		base.Maximize(driver);
		//Assert.assertEquals(bd.availableEntities().getText(), exc.GetObjectData(sheet3, "availableEntities"));
		new Select(bd.availableEntities()).selectByVisibleText("Satya [1]");
		bd.rightArrowButton().click();
		new Select(bd.contactTitle()).selectByVisibleText((exc.GetObjectData(sheet3, "contactTitle")));
		bd.contactName().sendKeys(exc.GetObjectData(sheet3, "contactName"));
		bd.address().sendKeys(exc.GetObjectData(sheet3, "address"));
		bd.city().sendKeys(exc.GetObjectData(sheet3, "city"));
		new Select(bd.state()).selectByVisibleText(exc.GetObjectData(sheet3, "state"));
		bd.country().sendKeys(exc.GetObjectData(sheet3, "country"));
		bd.postcode().sendKeys(exc.GetObjectData(sheet3, "postcode"));
		bd.phoneNumber().sendKeys(exc.GetObjectData(sheet3, "phoneNumber"));
		bd.mobile().sendKeys(exc.GetObjectData(sheet3, "mobile"));
		bd.fascimileNumber().sendKeys(exc.GetObjectData(sheet3, "fascimileNumber"));
		bd.mail().sendKeys(exc.GetObjectData(sheet3, "emailAddress"));
		bd.save().click();
		switchWindow.SwitchToChildWindow(driver);
		bd.radiobutton().click();
		bd.next().click();
		
		//
		Boolean load3 = js.waitforJStoLoad();
		Assert.assertTrue(load3);
		
		
		
		
		
	
	}
}
