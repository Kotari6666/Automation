package CBIG_PageObjects;

public class CreditLimitDetails {

	public CreditLimitDetails() {
		// TODO Auto-generated constructor stub
	}

}
