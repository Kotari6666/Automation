package CBIG_PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CPID_Page {

	WebDriver driver;
	
	public CPID_Page(WebDriver driver) {
		this.driver=driver;
	}
	By Country = By.xpath("//li[@class='clsCountryClosed']");
	By District = By.xpath("//ul/li/ul/li[@class='clsSegmentClosed']");
	By Region = By.xpath("//li[@class='clsDistrictOpen']/ul[4]//li[@class='clsRegionClosed']");
	By Region_2 = By.xpath("//li[@class='clsDistrictOpen']/ul[4]//li[@class='clsRegionClosed']/ul[4]/li");
	By CPID_R0000 = By.xpath("//a[@href='SME_CG_SelCustGroup.asp?App=IG&CPID=231&CPIDDesc=R0000&country=AU']");
	
	public WebElement Country()
	{
		return driver.findElement(Country);
	}
	
	public WebElement District()
	{
		return driver.findElement(District);
	}

	public WebElement Region()
	{
		return driver.findElement(Region);
	}
	
	public WebElement Region_2()
	{
		return driver.findElement(Region_2);
	}
	
	public WebElement CPID_R0000()
	{
		return driver.findElement(CPID_R0000);
	}
}
