package CBIG_PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CLG_Details {
	public WebDriver driver;
		

	public CLG_Details(WebDriver driver) {
		this.driver=driver;
	}
	//Locators of the fields
	By CLGNumber = By.id("txtCLGNO");
	By customerGroupName = By.id("txtCLGName");
	By ANZSICcode = By.id("txtANZSICCode");
	By ANZSICdescription = By.xpath("//table/tbody/tr[6]/td[2]");
	By customerSince = By.id("txtCustSince");
	By contactTitle =By.id("cboTitle");
	By contactName = By.id("txtContactName");
	By address = By.id("txtAddress");
	By city = By.id("txtCity");
	By state = By.id("cboState");
	By country = By.id("txtCountry");
	By postcode = By.id("txtPostCode");
	By phoneNumber = By.id("txtPhone");
	By mobile = By.id("txtMobile");
	By facimileNumber = By.id("txtFax");
	By emailAddress = By.id("txtEMail");
	By save = By.xpath("//img[@alt='save customer group details']");
	
	public WebElement CLGNumber()
	{
		return driver.findElement(CLGNumber);
	}
	public WebElement customerGroupName()
	{
		return driver.findElement(customerGroupName);
	}
	
	public WebElement ANZSICcode()
	{
		return driver.findElement(ANZSICcode);
	}
	public WebElement ANZSICdescription()
	{
		return driver.findElement(ANZSICdescription);
	}
	
	public WebElement customerSince()
	{
		return driver.findElement(customerSince);
	}
	public WebElement contactTitle()
	{
		return driver.findElement(contactTitle);
	}
	public WebElement contactName()
	{
		return driver.findElement(contactName);
	}
	public WebElement address()
	{
		return driver.findElement(address);
	}
	public WebElement city()
	{
		return driver.findElement(city);
	}
	public WebElement state()
	{
		return driver.findElement(state);
	}
	public WebElement country()
	{
		return driver.findElement(country);
	}
	public WebElement postcode()
	{
		return driver.findElement(postcode);
	}
	public WebElement phoneNumber()
	{
		return driver.findElement(phoneNumber);
	}
	public WebElement mobile()
	{
		return driver.findElement(mobile);
	}
	public WebElement facimileNumber()
	{
		return driver.findElement(facimileNumber);
	}
	public WebElement emailAddress()
	{
		return driver.findElement(emailAddress);
	}
	public WebElement save()
	{
		return driver.findElement(save);
	}
	


}
