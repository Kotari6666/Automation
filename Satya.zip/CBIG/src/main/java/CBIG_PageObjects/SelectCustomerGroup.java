package CBIG_PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SelectCustomerGroup {


	WebDriver driver;
	
	public  SelectCustomerGroup(WebDriver driver) 
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

		By CustomerGroupName1 = By.xpath("//input[@name='txtCLGName']");
		
		@FindBy(xpath="//input[@name='txtCLGNo']")
		WebElement CustomerGroupName;
		
		By CLGNumber = By.xpath("//input[@name='txtCLGNo']");
		By SearchButton = By.xpath("//img[@alt='search for a customer group']");
		By AddCGButton = By.xpath("//img[@alt='add a new CLG']");
		By resultCLG = By.xpath("//table[@id='tblCustDetails']/tbody/tr/td[2]");
		By open = By.xpath("//img[@alt='open a CLG']");
		
		public WebElement CustomerGroupName() 
		{
			return CustomerGroupName ;
		}
		
		public WebElement CLGNumber()
		{
			return driver.findElement(CLGNumber);
		}
		
		public WebElement SearchButton()
		{
			return driver.findElement(SearchButton);
		}
		
		public WebElement AddCGButton()
		{
			return driver.findElement(AddCGButton);
		}
		public WebElement resultCLG()
		{
			return driver.findElement(resultCLG);
		}
		public WebElement open()
		{
			return driver.findElement(open);
		}

}
