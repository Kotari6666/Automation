package CBIG_PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EntityDetails {

	WebDriver driver;
	
	public EntityDetails(WebDriver driver) {
		
		this.driver=driver;
		
	}
	
	By entityDetailsButton = By.xpath("//a[contains(@href , 'Entdet')]");
	By add = By.xpath("//img[@alt='add an entity']");
	public By entityType = By.id("cboEntityType");
	By entityName = By.id("txtEntityName");
	By sequenceNo = By.id("txtSeqNo");
	By ABN = By.id("txtABN");
	By save = By.id("imgSave");
	By radioButton =By.xpath("//input[@name='radio1']");
	By changeCGbutton = By.xpath("//img[@alt='change customer group']");
	
	
	public WebElement entityDetails()
	{
		return driver.findElement(entityDetailsButton);
	}
	public WebElement add()
	{
		return driver.findElement(add);
	}
	public WebElement entityType()
	{
		return driver.findElement(entityType);
	}
	public WebElement entityName()
	{
		return driver.findElement(entityName);
	}
	public WebElement sequenceNo()
	{
		return driver.findElement(sequenceNo);
	}
	public WebElement ABN()
	{
		return driver.findElement(ABN);
	}
	public WebElement save()
	{
		return driver.findElement(save);
	}
	public WebElement radioButton()
	{
		return driver.findElement(radioButton);
	}
	public WebElement changeCGbutton()
	{
		return driver.findElement(changeCGbutton);
	}

}
