package CBIG_PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage 
{
	
	public WebDriver driver;
	
	public LandingPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By CBIGLink=By.xpath("//a[contains(@onclick , 'App=IG')]");
	
	
	public WebElement ClickCbig()
	{
		return driver.findElement(CBIGLink);
	}

}
