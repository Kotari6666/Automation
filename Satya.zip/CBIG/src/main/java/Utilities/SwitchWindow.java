package Utilities;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SwitchWindow {

	WebDriver driver;
	
	
	
	public WebDriver SwitchToChildWindow(WebDriver driver)
	{
		this.driver=driver;
		WebDriverWait wait = new WebDriverWait(driver,10);
		Boolean numberOfWindows=wait.until(ExpectedConditions.numberOfWindowsToBe(2));
		
		if(numberOfWindows==true)
		{
		Set<String> windowsOpened =driver.getWindowHandles();
		Iterator <String> it = windowsOpened.iterator();
		
			@SuppressWarnings("unused")
			String parentWindow = it.next();
			String childWindow = it.next();
			
			driver.switchTo().window(childWindow);
			return driver;
		}
		else
		{
		System.out.println("no child window present");
		return driver;
		}
	}
	public WebDriver SwitchToSubChildWindow(WebDriver driver)
	{
		this.driver=driver;
		WebDriverWait wait = new WebDriverWait(driver,10);
		Boolean numberOfWindows = wait.until(ExpectedConditions.numberOfWindowsToBe(3));
		
		if(numberOfWindows==true)
		{
		Set<String> windowsOpened =driver.getWindowHandles();
		Iterator <String> it = windowsOpened.iterator();
		
			it.next();
			@SuppressWarnings("unused")
			String parentWindow = it.next();
			String childWindow = it.next();
			
			driver.switchTo().window(childWindow);
			return driver;
		}
		else
		{
		System.out.println("no sub-child window present");
		return driver;
		}
		
		
	}

}
