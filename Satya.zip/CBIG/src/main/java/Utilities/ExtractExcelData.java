package Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExtractExcelData {

	
	
	public String GetObjectData(String SheetName,String objectName) throws IOException
	{
		FileInputStream fis = new FileInputStream("D:\\Satya\\Test Data\\CBIG.xlsx");
		
		
		
		//Create an Object of below class coz this class contains all the methods to extract excel data
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		
		//Creating a loop to check sheet names and load the sheet if the name matches
		int sheets = workbook.getNumberOfSheets();
		String value = null;
		
		for(int i=0;i<sheets;i++)
		{
			if(workbook.getSheetName(i).equalsIgnoreCase(SheetName))
			{
				XSSFSheet sheet = workbook.getSheetAt(i);
				
				//Declaring an Iterator to iterate throught the rows of the sheet
				Iterator<Row> rows = sheet.rowIterator();
				Row firstrow = rows.next();
				
				//Declaring an Iterator to iterate through the cells of the sheet
				Iterator<Cell> cell = firstrow.cellIterator();
				int k=0;
				int column = 0;
				
				//Getting cell value and verifying
				while(cell.hasNext())
				{
					Cell cellValue = cell.next();
					
					if(cellValue.getStringCellValue().equalsIgnoreCase("Field Name"))
					{
						column=k;
					}
					k++;
					break;
						
				}
				
				while(rows.hasNext())
				{
					Row r=rows.next();
					
					if(r.getCell(column).getStringCellValue().equalsIgnoreCase(objectName))
					{
						Iterator<Cell> cv =r.cellIterator();
						while(cv.hasNext())
						{
							cv.next();
							
							Cell c =cv.next();
							
							
							
							
							if(c.getCellType()==CellType.STRING)
							{
							 value=(c.getStringCellValue());
							}
							else if(c.getCellType()==CellType.FORMULA)
							{
								cv.next();//coz formula has issue debug to know while commenting this line
							if(c.getCachedFormulaResultType()==CellType.NUMERIC)
								{
								value=(NumberToTextConverter.toText(c.getNumericCellValue()));
								}
								else 
								{
									value=(c.getStringCellValue());
								}
								
								 
								
							}
							else if(c.getCellType()==CellType.NUMERIC)
							{
								value=(NumberToTextConverter.toText(c.getNumericCellValue()));
							}
						
						}
						
					}
				}
			}
				}
		
		
		workbook.close();
		return value;
		
			
			
	
		
		
	}
}
