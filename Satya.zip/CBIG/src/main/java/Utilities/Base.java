package Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Base {

	public WebDriver driver;
	Properties prop = new Properties();
	
	

	public WebDriver intializeDriver() throws IOException {
		
		FileInputStream fis = new FileInputStream("D:\\Satya\\CBIG\\Configuration.properties");
		prop.load(fis);
		String browserName = prop.getProperty("browser");
		
		
		if (browserName.equals("InternetExplorer") )
		{
			System.setProperty("webdriver.ie.driver", "//D:\\\\IE WebDriver/IEDriverServer.exe");
			driver = new InternetExplorerDriver();

		} else if (browserName.equals("Edge"))
		{
			// Edge Location
		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		fis.close();
		return driver;
		
	}
	
	public WebDriver URL(WebDriver driver) throws IOException
	{
		this.driver=driver;
		FileInputStream fis = new FileInputStream("D:\\Satya\\CBIG\\Configuration.properties");
		prop.load(fis);
		String URL = prop.getProperty("URL");
		driver.navigate().to(URL);
		fis.close();
		return driver;
	}
	
	
	public WebDriver Maximize(WebDriver driver)
	{
		driver.manage().window().maximize();
		return driver;
	}
	
}