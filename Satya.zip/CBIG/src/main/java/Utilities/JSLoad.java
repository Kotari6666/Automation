package Utilities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JSLoad {

	WebDriver driver;
	
	public JSLoad(WebDriver driver) 
	{
		this.driver=driver;
		
	}
	
public boolean waitforJStoLoad()
{
	WebDriverWait wait= new WebDriverWait(driver,10);
	JavascriptExecutor js = (JavascriptExecutor)driver;
	
	//wait for jquery to load
	ExpectedCondition<Boolean> jqueryLoad = new ExpectedCondition<Boolean>()
			{
		@Override
		public Boolean apply(WebDriver driver)
		{
			try {
				return(js.executeScript("return jQuery.active").equals(0));
			}
			catch (Exception e)
			{return true;
			}
		}
			};
			// wait for Javascript to load
			ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>()
			{
		@Override
		public Boolean apply(WebDriver driver)
		{
			
				return(js.executeScript("return document.readyState").toString().equals("complete"));
			
		}
			};
	return wait.until(jqueryLoad) && wait.until(jsLoad);		
}

}
